#include <string>
#include <deque>
#include <sstream>
#include <iostream>


namespace Ini {
   
   bool isElementOf(char ch, const std::string& str);
   
   
   class Name {
      std::string                name_;
      
   public:
      Name(const char* name);
      Name(const std::string& name);
      friend bool operator== (const std::string& strName, const Name& name);
      operator const std::string&() const;

      inline std::string& str() {
         return name_;
      }

      inline const std::string& str() const {
         return name_;
      }
   };


   struct Variable {
      std::string                name_;
      std::string                value_;
      int                        precedingEmptyLines_;
      
      Variable(const std::string& name, const std::string& val, int lines = 0);
   };


   struct Section {
      std::string                name_;
      std::deque<Variable>       variables_;
      int                        precedingEmptyLines_;
      
   public:
      Section(const std::string& name, int lines = 0);
      std::deque<Variable>::const_iterator findName(const Name& name) const;
      std::deque<Variable>::iterator findName(const Name& name);
      static Name normalizeName(const Name& name);
		int size() const  {
			return (int)variables_.size();
		}

      void compact();
   };


   class File {
      std::deque<Section>        sections_;
      std::string                filename_;
      
      std::string                separators_;
      
   public:
      File(const char* filename);

		// was file opened ok (it can be opened even if it doesn't exist, it's just empty!)?
		bool ok() const {
			return sections_.size() > 0;
		}

		// is file empty (or it doesn't exist)?
		bool empty() const {
			return (!ok() || ((sections_.size() == 1) && (sections_[0].size() == 0)));
		}

      bool save() const;

      // section handlers
      // default section has number 0, result -1 marks an error
      int getSectionNumber(const std::string& name) const;
      
      // variable handlers
      template<class T>
      bool loadVar(T& var, Name name, int section = 0) const {
         if ((section >= (int)sections_.size()) || (section < 0))
            return false;
            
         std::deque<Variable>::const_iterator    it = sections_[section].findName(name);
         if (it != sections_[section].variables_.end()) {
            std::stringstream(it->value_) >> var;
            return true;
         }
         return false;
      }

      bool loadVar(std::string& var, Name name, int section) const;
      
      int addSection(Name name, int emptyLines = 0);
      void compactSection(int section);
      template<class T>
      void storeVar(const T& var, Name name, int section = 0) {
         if (section >= sections_.size())
            return;
            
         std::stringstream                   tempStream;
         tempStream << var;
         std::deque<Variable>::iterator      it = sections_[section].findName(name);
         if (it != sections_[section].variables_.end()) {
            it->value_ = tempStream.str();
         } else {
            sections_[section].variables_.push_front(Variable(name, tempStream.str()));
         }
      }
      
      void print();
      
   protected:
      void parse(const std::string& input, std::string& name, std::string& val) const;
      bool isSection(const std::string& name) const;
      int findSection(const std::string& name) const;
   };


   class CharSeparator {
      std::string                chars_;
   public:
      CharSeparator(const std::string& chars = " ;,\t");
      bool removeFrom(std::istream& inStream);
      bool removeFirst(std::istream& inStream);
   };


   template <class T, class Container>
   struct addToStdContainer { 
      void operator() (Container& cont, const T& element) {
         cont.push_back(element);
      }
   };


   template <class T, class ArrayT, class AddFunc = addToStdContainer<T, ArrayT>, class Separator = CharSeparator>
   class ArrayReader {
      ArrayT&                    target_;
      unsigned int               limit_;
      Separator                  separator_;
		AddFunc							addFunc_;
      
   public:
      ArrayReader(ArrayT& target, unsigned int limit = -1) 
         : target_(target), 
         limit_(limit)
      {
      }
      
      friend std::istream& operator>>(std::istream& inStream, ArrayReader& reader) {
         if (!reader.separator_.removeFirst(inStream))
            return inStream;
            
         while (inStream.good()) {
            T                    temp;
            inStream >> temp;
            reader.addFunc_(reader.target_, temp);
            if (!reader.separator_.removeFrom(inStream))
               break;
            
            if (reader.limit_ != 0) {
               --reader.limit_;
               if (reader.limit_ == 0)
                  break;
            }
         }
         
         return inStream;
      }
   };



}
